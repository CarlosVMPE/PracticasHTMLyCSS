$(document).ready(function(){
	$("#file").on("change", function(e){
        

		var files = $(this)[0].files;
		if(files.length >= 2){
			$("#label-span").text(files.length + " files ready to upload");
		}else{
			var fileName = e.target.value.split('\\').pop();
			$("#label-span").text(fileName);
			$("label span").prop("title", function (){
			    return fileName;
			});
		}

		if(files.length === 0){
			$("#label-span").text("Select files to upload");

		}
	});
});